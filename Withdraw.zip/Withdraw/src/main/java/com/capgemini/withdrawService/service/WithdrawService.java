package com.capgemini.withdrawService.service;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.withdrawService.model.BankAccount;
import com.capgemini.withdrawService.repository.WithdrawRepository;

@Service
public class WithdrawService {
	
		@Autowired
		WithdrawRepository repo;
		
		
		public void withdraw(int accNo, double amount) {
			BankAccount account=repo.findByAccountNo(accNo);
			double balance=account.getAccountBalance();
			balance-=amount;
			account.setAccountBalance(balance);
			
			repo.save(account);
		}
		
		
		
	}


