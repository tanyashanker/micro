package com.capgemini.accountService.repository;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.capgemini.accountService.model.BankAccount;

public interface BankRepository extends MongoRepository<BankAccount, String>{
	
	public BankAccount findByAccountNo(int accNo);
	
	

}
