package com.capgemini.accountService.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.accountService.model.BankAccount;
import com.capgemini.accountService.service.BankService;


@RestController
public class BankController {

	@Autowired
	BankService service;
	
	@PostMapping("/add")
	public void create(@RequestBody BankAccount account)
	{
		service.create(account);
	}
	
	@GetMapping("/balance")
	public double getBalance(@RequestParam ("accountNo") int accNo)
	{
	return service.getBalance(accNo);
	}

}
