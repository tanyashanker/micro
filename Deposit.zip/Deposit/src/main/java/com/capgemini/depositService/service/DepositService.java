package com.capgemini.depositService.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.depositService.model.BankAccount;
import com.capgemini.depositService.repository.DepositRepository;

@Service
public class DepositService {

	@Autowired
	DepositRepository repo;
	
	
	public void deposit(int accNo, double amount) {
		BankAccount account=repo.findByAccountNo(accNo);
		double balance=account.getAccountBalance();
		balance+=amount;
		account.setAccountBalance(balance);
		repo.save(account);
	}

	
}
