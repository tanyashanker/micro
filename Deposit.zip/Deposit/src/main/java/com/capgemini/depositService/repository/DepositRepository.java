package com.capgemini.depositService.repository;


import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import com.capgemini.depositService.model.BankAccount;


@Repository
public interface DepositRepository extends MongoRepository<BankAccount, String>{


	public BankAccount findByAccountNo(int accNo);
	
}
